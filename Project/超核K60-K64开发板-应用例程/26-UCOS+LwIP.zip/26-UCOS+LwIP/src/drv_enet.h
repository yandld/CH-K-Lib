#ifndef __CH_DRV_ENET_H__
#define __CH_DRV_ENET_H__

#include <stdint.h>

uint32_t OSENET_Init(void);
uint32_t OSLwIP_Init(void);



#endif
