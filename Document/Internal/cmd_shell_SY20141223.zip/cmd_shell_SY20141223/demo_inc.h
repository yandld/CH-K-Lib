/* demo_inc.h */

#ifndef __DEMO_INC_H__
#define __DEMO_INC_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "cmd_shell.h"

/*---------------------------------------------------------------------------
 * Adapter would implement these APIs.
 *-------------------------------------------------------------------------*/
extern const CMD_HandlerCallback_T gCmdHandlerCallbackStruct;
bool init_platform(void);
void exit_platform(void);

#endif /* __DEMO_INC_H__ */
