Cracked by XiaoGo_O

DEMO code in Serial Digital Scope Code

implement USART putchar before use.

have fun!

2014-10-14