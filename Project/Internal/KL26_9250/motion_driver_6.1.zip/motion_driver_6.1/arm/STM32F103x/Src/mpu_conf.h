
#ifndef _MPU_CONF_
#define _MPU_CONF_

#if 1
#define MPL_LOG_NDEBUG  1
#define EMPL
#define MPU9250
#define EMPL_TARGET_STM32
#endif

#endif
