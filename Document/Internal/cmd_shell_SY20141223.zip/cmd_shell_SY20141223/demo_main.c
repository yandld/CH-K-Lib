/* demo_main.c */

#include "demo_inc.h"

static int32_t do_show_logo(int32_t argc, char *argv[]);
static int32_t do_show_param(int32_t argc, char *argv[]);

CMD_TableItem_T DemoCmdTable[] =
{
    {"logo", 1, do_show_logo},
    {"param", 4, do_show_param},
    {NULL}
};

int main(void)
{
    init_platform();

    printf("\r\n*----------------------------------------\r\n");
    printf("* Welcome to sdcard_spi demo project.\r\n");
    printf("* Compiled at %s on %s\r\n", __TIME__, __DATE__);
    printf("*----------------------------------------*\r\n\r\n");
    
    CMD_InstallHandler(&gCmdHandlerCallbackStruct);

    while (1)
    {
        CMD_LoopShell(DemoCmdTable);
    }
    //return 0;
}

static int32_t do_show_logo(int32_t argc, char *argv[])
{
    printf("do_print_logo()\r\n");
    printf("\r\n");
    printf("*----------------------------------------*\r\n");
    printf("Hello, This is mini command shell.\r\n");
    printf("*----------------------------------------\r\n");
    printf("\r\n");
    return 0;
}

static int32_t do_show_param(int32_t argc, char *argv[])
{
    int32_t i;
    printf("do_show_param()\r\n");
    for (i = 0; i < argc; i++)
    {
        printf("%s\r\n", argv[i]);
    }
    printf("\r\n");
		return 0;
}


/* EOF. */
