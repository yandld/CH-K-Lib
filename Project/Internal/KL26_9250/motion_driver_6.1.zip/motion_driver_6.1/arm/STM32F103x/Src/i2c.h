/****************************************Copyright (c)**************************************************                         
**
**                                 http://www.powermcu.com
**
**--------------File Info-------------------------------------------------------------------------------
** File name:           24C02.h
** Descriptions:        24C02 ���������� 
**
**------------------------------------------------------------------------------------------------------
** Created by:          AVRman
** Created date:        2010-10-29
** Version:             1.0
** Descriptions:        The original version
**
**------------------------------------------------------------------------------------------------------
** Modified by:         
** Modified date:   
** Version:
** Descriptions:        
********************************************************************************************************/
#ifndef __MPU_I2C_H_
#define __MPU_I2C_H_
#include "stm32f10x.h"
#include "datatype.h"

/* Private function prototypes -----------------------------------------------*/
void InitI2C1(void);
void I2CTest(void);


BOOL MpuReadData(uint8_t reg,uint8_t *buf,uint8_t len);
BOOL MpuWriteData(uint8_t reg,const uint8_t *buf,uint8_t len);

INT8 stm_i2c_read(UINT8 slave_addr,
                    UINT8 reg_addr,
                    UINT8 length,
                    UINT8 *data);

INT8 stm_i2c_write(UINT8 slave_addr,
                     UINT8 reg_addr,
                     UINT8 length,
                     UINT8 *data);

BOOL I2CReadByte(UINT8 reg,UINT8 *data);
BOOL I2CWriteByte(UINT8 reg,UINT8 data);
BOOL I2CReadBytes(UINT8 reg,UINT8 size,UINT8 *buf);
BOOL I2CWriteBytes(UINT8 reg,UINT8 size,UINT8 *buf);
UINT8 I2CReadBit(UINT8 regAddr, UINT8 bitNum, UINT8 *data);
UINT8 I2CReadBitW(UINT8 regAddr, UINT8 bitNum, UINT16 *data);
UINT8 I2CReadBits(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT8 *data);
UINT8 I2CReadBitsW(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT16 *data);

BOOL I2CWriteBit(UINT8 regAddr, UINT8 bitNum, UINT8 data);
BOOL I2CWriteBitW(UINT8 regAddr, UINT8 bitNum, UINT16 data);
BOOL I2CWriteBits(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT8 data);
BOOL I2CWriteBitsW(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT16 data) ;
#endif 
/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
