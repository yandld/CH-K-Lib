/* cmd_shell_sdapter.c */

#include "cmd_shell.h"
#include "fsl_hal_driver.h"
#include "bsp_config.h"

static void mSER_PutChar(char ch);
static char mSER_GetChar(void);

const CMD_HandlerCallback_T gCmdHandlerCallbackStruct =
{
    mSER_PutChar, /* void (*SER_PutCharFunc)(uint8_t txData); */
	  mSER_GetChar, /* char (*SER_GetCharFunc)(void); */
	  "CMD> "/* char *PromptStr; */
};

static void mSER_PutChar(char ch)
{
    UART0_PutTxDataBlocking((uint8_t)ch);
}

static char mSER_GetChar(void)
{
    return UART0_GetRxDataBlocking();
}




/* EOF. */
