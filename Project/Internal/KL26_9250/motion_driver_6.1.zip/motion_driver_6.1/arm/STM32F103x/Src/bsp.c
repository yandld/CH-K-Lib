//=============================================================================
// File Description: bsp.c
//=============================================================================
// Create by Cerik
//  
// System Clock Configuration
//     HSI = 8MHz
//     SYSCLK=PLLCLK = 48MHz = 8MHz/2 * 12
//     HCLK=48MHz
//     PCLK2(APB2)=12MHz
//     PCLK1(APB1)=24MHz
//     USBCLK = 48MHz
//     FCLK = 48MHz
//     SysTickCLK=HCLK/8=8MHz
//=============================================================================
// Log:
//=============================================================================
#include <stdio.h>
#include "stm32f10x_usart.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_iwdg.h"
#include "stm32f10x_spi.h"
#include "stm32f10x_adc.h"
#include "stm32f10x.h"
#include "datatype.h"
#include "misc.h"

//===================================================================
// Local Varibale & Macro Definition

// Tick Counter from power-on;
static UINT32 gSysTickCounter=0;

//struct __FILE {
//  int handle;   // Add whatever you need here 
//};
FILE __stdout;
FILE __stdin;

//===================================================================
// Description: Get a char from UART1
// Return     : One char UART1 received 
// Note       : RXNE will be auto cleared by software read to the 
//              UART_DR register.
UINT8 getch(void)
{
    while (!(USART1->SR & USART_FLAG_RXNE));
    return (UINT8)(USART1->DR & 0x1FF);
}
char putch(UINT8 dat)
{
    while(!(USART1->SR & USART_FLAG_TXE));
    USART1->DR = (dat & 0x1FF);
    return dat;
}
int fputc(int ch, FILE *f) {
    return putch(ch);
}
int fgetc(FILE *f) {
    return getch();
}
void _ttywrch(int ch) {
    putch(ch);
}
int ferror(FILE *f) {
    return EOF;
}
void _sys_exit(int return_code) {
label:  goto label;
}

//===================================================================
//   Independent Watchdog Configure
//   IWDGCLK = 40 kHz
//   WDT Timeout = 5s
//   CNT_CLK = 40 kHz / 256 = 156.25 Hz
#define __IWGDCLK     (40000UL/(0x04<<IWDG_Prescaler_256))
void InitWatchDog(UINT32 ms)
{
    UINT16 reload;
    reload = ms* 40000UL/(0x04<<IWDG_Prescaler_256)/1000UL-1;
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
    IWDG_SetPrescaler(IWDG_Prescaler_256);//clk = 40 kHz / 256 = 156.25 Hz
    IWDG_SetReload(reload);
    IWDG_ReloadCounter();
    IWDG_Enable();
}

UINT8 GetMpuIntPin(void)
{
    return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7);
}

//===================================================================
// Function Name  : EXTI_Configuration
// Description    : GPIOD_Pin_0 is MPU6050_INT Pin
// Mode:  Rising Trigger
// PA0  -> INT
void InitMpuInt(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    EXTI_InitTypeDef EXTI_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,ENABLE);
    
    //PA0 = MPU6050 INT
    // Configure GPIO Pin as input floating (INT EXTI Line)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;   
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // Connect EXTI Line 0 to INT GPIO Pin
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
    EXTI_ClearITPendingBit(EXTI_Line0);

    // Configure EXTI Line to generate an interrupt on Rising edge
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    
    EXTI_Init(&EXTI_InitStructure);
}

//===================================================================
// Function Name  : InitUart
// Description    : Configure USART1 
// Input          : None
// Output         : None
// Return         : None
// Attention      : None
void InitUart(void)
{ 
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure; 

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1,ENABLE);

    //USART1_TX -> PA9 , USART1_RX -> PA10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USART1, &USART_InitStructure); 
    USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
    USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
    USART_ClearFlag(USART1,USART_FLAG_TC);
    USART_Cmd(USART1, ENABLE);
}

//===================================================================
//  Tick Cycle = 1ms
//  SYSCLK = 72MHz
//  HCLK   = 72MHz
//  PCLK1  = 36MHz
//  PCLK2  = 72MHz
//  ADCCLK = 36MHz
void InitSysTick(UINT32 ms)
{
    INT32  cnts;
    RCC_ClocksTypeDef RCC_ClocksStatus;
    RCC_GetClocksFreq(&RCC_ClocksStatus);
  
    cnts = RCC_ClocksStatus.HCLK_Frequency/8/ (1000/ms);
    SysTick->LOAD  = (cnts - 1);
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;/* Enable timer interrupt. */
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; /* Enable timer.           */ 
}

//**********************************************************
// Initialize the ADC port: SPI1
//  PA5 --> AD_SCLK (SPI)
//  PA6 --> AD_MISO (SPI)
//  PA7 --> AD_MOSI (SPI)
void InitSPI1(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef  SPI_InitStructure;
    
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1 ,ENABLE);

    // SPI1_SCK ->PA5, SPI1_MISO->PA6, SPI1_MOSI->PA7
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);
    SPI_Cmd(SPI1, ENABLE);
}

//=================================================================
//  Free Run Timer : Timer2,configured as a free running timer.
//
//  PCLK1 = 24MHz , CLK_TIM2 = 2*PCLK1 = 48MHz
//  1. cycle = 1us.
//  2. It will support for the us delay function.
void InitUsTimer(void)
{
    RCC_ClocksTypeDef RCC_ClocksStatus;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    RCC_GetClocksFreq(&RCC_ClocksStatus);

    TIM_DeInit(TIM2);
    TIM_TimeBaseInitStruct.TIM_Period        = 0xFFFF;
    TIM_TimeBaseInitStruct.TIM_Prescaler     = RCC_ClocksStatus.PCLK1_Frequency *2/1000000-1; 
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    
    TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
    TIM_ITConfig(TIM2,TIM_IT_Update,DISABLE);
    TIM_Cmd(TIM2,ENABLE);
}

//=================================================================
//  Wait Timer: Timer3 as free running timer.
//
//  PCLK1 = 36MHz , CLK_TIM3 = 2*PCLK1 = 72MHz
// Configuration:
//    1.Free Running;
//    2.Counter up mode
//    3.counter cycle is 1ms;
void InitMsTimer(void)
{
    RCC_ClocksTypeDef RCC_ClocksStatus;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
    RCC_GetClocksFreq(&RCC_ClocksStatus);

    TIM_DeInit(TIM3);    
    TIM_TimeBaseInitStruct.TIM_Period        = 0xFFFF;
    TIM_TimeBaseInitStruct.TIM_Prescaler     = RCC_ClocksStatus.PCLK1_Frequency *2/1000-1;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    
    TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
    TIM_ClearFlag(TIM3, TIM_FLAG_Update);
    TIM_Cmd(TIM3,ENABLE);
}

//================================================================
// us base time delay.
// It based on the Timer 2
void WaitUs(INT32 us)
{
    UINT32 t0, t1;
    t0 = TIM_GetCounter(TIM2);;
    while ( us > 0 )
    {
        t1 = TIM_GetCounter(TIM2);;
        us -= (t1<t0)?(t1 + MAXUINT16 - t0):(t1-t0);
        t0 = t1;
    }
}

//**********************************************************
// The Wait MS function based on the TIMER3;
void  WaitMs(INT32 ms)
{
    UINT32 t0, t1;
    t0 = TIM_GetCounter(TIM3);
    while ( ms > 0 )
    {
        t1 = TIM_GetCounter(TIM3);
        ms -= (t1<t0)?(t1 + MAXUINT16 - t0):(t1-t0);
        t0 = t1;
    }
}

/*
 ***************************************************
 *   Free Counter Function Group
 *   Counter Unit: 1ms
 ***************************************************
 */
void StartCounter(tagCounter *counter,INT32 ms)
{
    counter->t0 = TIM_GetCounter(TIM3);    
    counter->ms = ms;
}

BOOL CounterArrived(tagCounter *counter)
{
    if(counter->ms > 0)
    {
        counter->t1 = TIM_GetCounter(TIM3);
        counter->ms -= (counter->t1 < counter->t0)?(counter->t1 + MAXUINT32 - counter->t0):(counter->t1 - counter->t0);
        counter->t0 = counter->t1;
    }
    return (counter->ms > 0)?FALSE:TRUE;
}

//=================================================================
//
void SysTick_Handler()
{
#if WDG_ENABLE
    IWDG_ReloadCounter();
#endif
    gSysTickCounter++;
}

UINT32 GetSysTickMs(void)
{
    return gSysTickCounter;
}

void gyro_data_ready_cb(void);

void EXTI0_IRQHandler(void)
{
    if ( EXTI_GetITStatus(EXTI_Line0) != RESET )    
    {        
        EXTI_ClearITPendingBit(EXTI_Line0);   
        gyro_data_ready_cb();
    }
}

