//=============================================================================
// File Description:
//
//=============================================================================
// Log:
//=============================================================================

#ifndef _DATATYPES_H_
#define _DATATYPES_H_

#include <stdbool.h>

#define  WDG_ENABLE  0

typedef         unsigned char  UINT8;
typedef           signed char  INT8;
typedef        unsigned short  UINT16;
typedef          signed short  INT16;
typedef          unsigned int  UINT32;
typedef            signed int  INT32;
typedef                 float  FLOAT32;
typedef                double  FLOAT64;
typedef    unsigned long long  UINT64;
typedef     signed long  long  INT64;

typedef volatile   signed int  VINT32;
typedef volatile unsigned int  VUINT32;
typedef char BOOL;
#define TRUE 1
#define FALSE 0

#define INV_SUCCESS                       (0)
/* Generic Error code.  Proprietary Error Codes only */
#define INV_ERROR_BASE                    (0x20)
#define INV_ERROR                         (INV_ERROR_BASE)

typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

#define NULLCHAR  '\0'
//#define NULL      0

#define MAXUINT8  0xFF
#define MAXUINT16 0xFFFF
#define MAXUINT32 0xFFFFFFFF

typedef struct {
    UINT8 lastUartCmd;
    UINT8 lastUsbCmd;
    union {
        UINT32 word;
        UINT32 bflick:1;//continue flick flag,1 = execute flick continue and report data to host.
        UINT32 bwave :1;//flick wave fliag,1= execute flick wave and report data to host.
    }devStatus;
}tatDevStatus;

typedef enum{GPIO_IN_MODE=0,GPIO_OUT_MODE=1} GPIOMODE;
typedef struct{
    INT32 ms;
    UINT32 t0,t1;
}tagCounter;



#define log_i(format,args...)     do {printf("[I]%s:%d->"format,__func__,__LINE__,##args);} while (0)
#define log_e(format,args...)     do {printf("[E]%s:%d->"format,__func__,__LINE__,##args);} while (0)










#ifndef EINVAL
#define EINVAL  (22)
#endif

#ifndef ENOMEM
#define ENOMEM  (12)
#endif

#ifndef EPERM
#define EPERM   (1)
#endif

/* Compatibility and other generic error codes */
#define INV_ERROR_INVALID_PARAMETER             (EINVAL)
#define INV_ERROR_FEATURE_NOT_ENABLED           (EPERM)
#define INV_ERROR_FEATURE_NOT_IMPLEMENTED       (INV_ERROR_BASE + 4)
#define INV_ERROR_DMP_NOT_STARTED               (INV_ERROR_BASE + 6)
#define INV_ERROR_DMP_STARTED                   (INV_ERROR_BASE + 7)
#define INV_ERROR_NOT_OPENED                    (INV_ERROR_BASE + 8)
#define INV_ERROR_OPENED                        (INV_ERROR_BASE + 9)
#define INV_ERROR_INVALID_MODULE                (ENODEV)
#define INV_ERROR_MEMORY_EXAUSTED               (ENOMEM)
#define INV_ERROR_DIVIDE_BY_ZERO                (INV_ERROR_BASE + 12)
#define INV_ERROR_ASSERTION_FAILURE             (INV_ERROR_BASE + 13)
#define INV_ERROR_FILE_OPEN                     (INV_ERROR_BASE + 14)
#define INV_ERROR_FILE_READ                     (INV_ERROR_BASE + 15)
#define INV_ERROR_FILE_WRITE                    (INV_ERROR_BASE + 16)
#define INV_ERROR_INVALID_CONFIGURATION         (INV_ERROR_BASE + 17)
#define INV_ERROR_NOT_AUTHORIZED                (INV_ERROR_BASE + 18)

/* Serial Communication */
#define INV_ERROR_SERIAL_CLOSED                 (INV_ERROR_BASE + 20)
#define INV_ERROR_SERIAL_OPEN_ERROR             (INV_ERROR_BASE + 21)
#define INV_ERROR_SERIAL_READ                   (INV_ERROR_BASE + 22)
#define INV_ERROR_SERIAL_WRITE                  (INV_ERROR_BASE + 23)
#define INV_ERROR_SERIAL_DEVICE_NOT_RECOGNIZED  (INV_ERROR_BASE + 24)

/* SM = State Machine */
#define INV_ERROR_SM_TRANSITION                 (INV_ERROR_BASE + 25)
#define INV_ERROR_SM_IMPROPER_STATE             (INV_ERROR_BASE + 26)

/* Fifo */
#define INV_ERROR_FIFO_OVERFLOW                 (INV_ERROR_BASE + 30)
#define INV_ERROR_FIFO_FOOTER                   (INV_ERROR_BASE + 31)
#define INV_ERROR_FIFO_READ_COUNT               (INV_ERROR_BASE + 32)
#define INV_ERROR_FIFO_READ_DATA                (INV_ERROR_BASE + 33)

/* Memory & Registers, Set & Get */
#define INV_ERROR_MEMORY_SET                    (INV_ERROR_BASE + 40)

#define INV_ERROR_LOG_MEMORY_ERROR              (INV_ERROR_BASE + 50)
#define INV_ERROR_LOG_OUTPUT_ERROR              (INV_ERROR_BASE + 51)

/* OS interface errors */
#define INV_ERROR_OS_BAD_PTR                    (INV_ERROR_BASE + 60)
#define INV_ERROR_OS_BAD_HANDLE                 (INV_ERROR_BASE + 61)
#define INV_ERROR_OS_CREATE_FAILED              (INV_ERROR_BASE + 62)
#define INV_ERROR_OS_LOCK_FAILED                (INV_ERROR_BASE + 63)

/* Compass errors */
#define INV_ERROR_COMPASS_DATA_OVERFLOW         (INV_ERROR_BASE + 70)
#define INV_ERROR_COMPASS_DATA_UNDERFLOW        (INV_ERROR_BASE + 71)
#define INV_ERROR_COMPASS_DATA_NOT_READY        (INV_ERROR_BASE + 72)
#define INV_ERROR_COMPASS_DATA_ERROR            (INV_ERROR_BASE + 73)

/* Load/Store calibration */
#define INV_ERROR_CALIBRATION_LOAD              (INV_ERROR_BASE + 75)
#define INV_ERROR_CALIBRATION_STORE             (INV_ERROR_BASE + 76)
#define INV_ERROR_CALIBRATION_LEN               (INV_ERROR_BASE + 77)
#define INV_ERROR_CALIBRATION_CHECKSUM          (INV_ERROR_BASE + 78)

/* Accel errors */
#define INV_ERROR_ACCEL_DATA_OVERFLOW           (INV_ERROR_BASE + 79)
#define INV_ERROR_ACCEL_DATA_UNDERFLOW          (INV_ERROR_BASE + 80)
#define INV_ERROR_ACCEL_DATA_NOT_READY          (INV_ERROR_BASE + 81)
#define INV_ERROR_ACCEL_DATA_ERROR              (INV_ERROR_BASE + 82)

/* No Motion Warning States */
#define INV_WARNING_MOTION_RACE                 (INV_ERROR_BASE + 83)
#define INV_WARNING_QUAT_TRASHED                (INV_ERROR_BASE + 84)
#define INV_WARNING_GYRO_MAG                    (INV_ERROR_BASE + 85)

#define INV_WARNING_SEMAPHORE_TIMEOUT           (INV_ERROR_BASE + 86)


#ifdef  DEBUG
/*******************************************************************************
* Macro Name     : assert_param
* Description    : The assert_param macro is used for function's parameters check.
*                  It is used only if the library is compiled in DEBUG mode. 
* Input          : - expr: If expr is false, it calls assert_failed function
*                    which reports the name of the source file and the source
*                    line number of the call that failed. 
*                    If expr is true, it returns no value.
* Return         : None
*******************************************************************************/ 
#define assert_param(expr) ((expr) ? (void)0 : assert_failed((UINT8 *)__FILE__, __LINE__))
__inline  void assert_failed(UINT8* file, UINT32 line);
#else
  #define assert_param(expr) ((void)0)
#endif

#endif
