/****************************************Copyright (c)**************************************************                         
**
**                                 http://www.powermcu.com
**
**--------------File Info-------------------------------------------------------------------------------
** File name:           
**
**------------------------------------------------------------------------------------------------------
** SCL : PA5
** SDA : PA6
** INT : PA7
**------------------------------------------------------------------------------------------------------       
**  MPU6050: The highest speed of I2C interface is 400kHz.
********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "datatype.h"
#include "bsp.h"

/* Private define ------------------------------------------------------------*/
#define SCL1_H()       GPIOB->BSRR = GPIO_Pin_10
#define SCL1_L()       GPIOB->BRR  = GPIO_Pin_10
#define SDA1_H()       GPIOB->BSRR = GPIO_Pin_11
#define SDA1_L()       GPIOB->BRR  = GPIO_Pin_11

#define GetSCL1()      GPIOB->IDR  & GPIO_Pin_10
#define GetSDA1()      GPIOB->IDR  & GPIO_Pin_11

#define MPU6050_DEV_ADDR   (0x68<<1)

#define I2C_SIGNAL_DELAY 2
/*******************************************************************************
* Function Name  : I2C_Configuration
* Description    : MPU6050 Operation
* Input          : None
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
void InitI2C1(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure; 

    //PB11 -> SCL
    //PB10 -> SDA
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_11 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;  
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void I2CTest(void)
{
    SCL1_H();
    SDA1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_L();
    SDA1_H();
    WaitUs(I2C_SIGNAL_DELAY);
}

/*******************************************************************************
* Function Name  : I2C_Start
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
static BOOL I2C1_Start(void)
{
    SDA1_H();
    SCL1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    if(!GetSDA1())return FALSE;    /* SDA��Ϊ�͵�ƽ������æ,�˳� */
    SDA1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    if(GetSDA1()) return FALSE;    /* SDA��Ϊ�ߵ�ƽ�����߳���,�˳� */
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    return TRUE;
}

/*******************************************************************************
* Function Name  : I2C_Stop
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
static void I2C1_Stop(void)
{
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SDA1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    SDA1_H();
    WaitUs(I2C_SIGNAL_DELAY);
}

/*******************************************************************************
* Function Name  : I2C_Ack
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
static void I2C1_Ack(void)
{   
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SDA1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
}

/*******************************************************************************
* Function Name  : I2C_NoAck
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
static void I2C1_NoAck(void)
{   
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SDA1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
}

/*******************************************************************************
* Function Name  : I2C_WaitAck
* Description    : None
* Input          : None
* Output         : None
* Return         : ����Ϊ:=1��ACK,=0��ACK
* Attention      : None
*******************************************************************************/
static BOOL I2C1_WaitAck(void)     
{
    SCL1_L();
    WaitUs(I2C_SIGNAL_DELAY);
    SDA1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    SCL1_H();
    WaitUs(I2C_SIGNAL_DELAY);
    if(GetSDA1())
    {
      SCL1_L();
      return FALSE;
    }
    SCL1_L();
    return TRUE;
}

 /*******************************************************************************
* Function Name  : I2C_SendByte
* Description    : MSB First
* Input          : - SendByte --being send data
* Output         : None
* Return         : None
* Attention      : None
*******************************************************************************/
static void I2C1_SendByte(UINT8 SendByte) 
{
    INT8 i=8;
    while(i--)
    {
        SCL1_L();
        WaitUs(I2C_SIGNAL_DELAY);
        if(SendByte&0x80)
            SDA1_H();
        else
            SDA1_L();
        SendByte<<=1;
        WaitUs(I2C_SIGNAL_DELAY);
        SCL1_H();
        WaitUs(I2C_SIGNAL_DELAY);
    }
    SCL1_L();
}

/*******************************************************************************
* Function Name  : I2C_ReceiveByte
* Description    : MSB First
* Input          : None
* Output         : None
* Return         : Received byte
* Attention      : None
*******************************************************************************/
static UINT8 I2C1_ReceiveByte(void)  
{ 
    INT8 i=8;
    UINT8 ReceiveByte=0;

    SDA1_H();
    while(i--)
    {
      ReceiveByte<<=1;
      SCL1_L();
      WaitUs(I2C_SIGNAL_DELAY);
      SCL1_H();
      WaitUs(I2C_SIGNAL_DELAY);  
      if(GetSDA1())
      {
        ReceiveByte|=0x01;
      }
    }
    SCL1_L();
    return ReceiveByte;
}

INT8 stm_i2c_write(UINT8 slave_addr,
                   UINT8 reg,
                   UINT8 length,
                   UINT8 *data)
{
    if(0 == length || !data ) return 1;
    if(!I2C1_Start())   return 2;
    
    I2C1_SendByte(slave_addr);//Physical Address
    if(!I2C1_WaitAck()) return 3;
    
    I2C1_SendByte(reg);    //Register Address
    if(!I2C1_WaitAck()) return 4;
    
    while(length--)
    {
        I2C1_SendByte(*data++);
        if(!I2C1_WaitAck()) return 5;
    }
    I2C1_Stop();
    return 0;
}

INT8 stm_i2c_read(UINT8 slave_addr,UINT8 reg,UINT8 length, UINT8 *data)
{
    if( (0 == length) || !data ) return 1;
    
    if(!I2C1_Start())   return 2;
    I2C1_SendByte(slave_addr);//Physical Address + Write Bit
    if(!I2C1_WaitAck()) return 3;
    I2C1_SendByte(reg);    //Register Address
    if(!I2C1_WaitAck()) return 4;
    
    if(!I2C1_Start())   return 5;
    I2C1_SendByte(slave_addr+1);//Physical Address + Read Bit
    if(!I2C1_WaitAck()) return 6;

    while(length)
    {
        *data++ = I2C1_ReceiveByte();
        (length == 1)?(I2C1_NoAck()):(I2C1_Ack());
        length--;
    }
    I2C1_Stop();
    return 0;
}

/*******************************************************************************
* Description    : Write Multiple or Single byte to MPU6050 from 
*                  the special register address.
* Input          : 
* Output         : None
* Return         : FALSE -- failure. TURE--success.
*******************************************************************************/           
BOOL MpuWriteData(UINT8 reg,const UINT8 *buf,UINT8 len)
{
    const UINT8 devAddr = MPU6050_DEV_ADDR;

    if(0 == len) return FALSE;
    if(!I2C1_Start())   return FALSE;
    
    I2C1_SendByte(devAddr);//Physical Address
    if(!I2C1_WaitAck()) return FALSE;
    
    I2C1_SendByte(reg);    //Register Address
    if(!I2C1_WaitAck()) return FALSE;
    
    while(len--)
    {
        I2C1_SendByte(*buf++);
        if(!I2C1_WaitAck()) return FALSE;
    }
    I2C1_Stop();
    return TRUE;
}

/*******************************************************************************
* Function Name  : MpuReadByte
* Description    : Read Muiltiple Byte from the start of speciall register addr.
* Input          : - pBuffer: 
*                  - length:
*                  - ReadAddress: 
* Output         : None
* Return         : FALSE/TRUE
* Attention      : None
*******************************************************************************/          
BOOL MpuReadData(UINT8 reg,UINT8 *buf,UINT8 len)
{
    const UINT8 devAddr = MPU6050_DEV_ADDR;

    if( (0 == len) || !buf ) 
        return FALSE;
    
    if(!I2C1_Start()) 
        return FALSE;
    I2C1_SendByte(devAddr);//Physical Address + Write Bit
    if(!I2C1_WaitAck()) 
        return FALSE;
    I2C1_SendByte(reg);    //Register Address
    if(!I2C1_WaitAck()) 
        return FALSE;
    
    if(!I2C1_Start()) 
        return FALSE;
    I2C1_SendByte(devAddr+1);//Physical Address + Read Bit
    if(!I2C1_WaitAck()) 
        return FALSE;

    while(len)
    {
        *buf++ = I2C1_ReceiveByte();
        (len == 1)?(I2C1_NoAck()):(I2C1_Ack());
        len--;
    }
    I2C1_Stop();
    return TRUE;
}

BOOL I2CReadByte(UINT8 reg,UINT8 *data)
{
    return MpuReadData(reg,data,1);
}

BOOL I2CWriteByte(UINT8 reg,UINT8 data)
{
    return MpuWriteData(reg,&data,1);
}

BOOL I2CReadBytes(UINT8 reg,UINT8 size,UINT8 *buf)
{
    return MpuReadData(reg,buf,size);
}

BOOL I2CWriteBytes(UINT8 reg,UINT8 size,UINT8 *buf)
{
    return MpuWriteData(reg,buf,size);
}


/** Read a single bit from an 8-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to read from
 * @param bitNum Bit position to read (0-7)
 * @param data Container for single bit value
 * @param timeout Optional read timeout in milliseconds (0 to disable, leave off to use default class value in I2Cdev::readTimeout)
 * @return Status of read operation (true = success)
 */
UINT8 I2CReadBit(UINT8 regAddr, UINT8 bitNum, UINT8 *data) {
    UINT8 b;
    UINT8 count = MpuReadData(regAddr, &b, 1);
    *data = b & (1 << bitNum);
    return count;
}

/** Read a single bit from a 16-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to read from
 * @param bitNum Bit position to read (0-15)
 * @param data Container for single bit value
 * @param timeout Optional read timeout in milliseconds (0 to disable, leave off to use default class value in I2Cdev::readTimeout)
 * @return Status of read operation (true = success)
 */
UINT8 I2CReadBitW(UINT8 regAddr, UINT8 bitNum, UINT16 *data) {
    UINT16 b;
    UINT8 count = MpuReadData(regAddr, (UINT8*)&b, 2);
    *data = b & (1 << bitNum);
    return count;
}

/** Read multiple bits from an 8-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to read from
 * @param bitStart First bit position to read (0-7)
 * @param length Number of bits to read (not more than 8)
 * @param data Container for right-aligned value (i.e. '101' read from any bitStart position will equal 0x05)
 * @param timeout Optional read timeout in milliseconds (0 to disable, leave off to use default class value in I2Cdev::readTimeout)
 * @return Status of read operation (true = success)
 */
UINT8 I2CReadBits(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT8 *data) {
    // 01101001 read byte
    // 76543210 bit numbers
    //    xxx   args: bitStart=4, length=3
    //    010   masked
    //   -> 010 shifted
    UINT8 count, b;
    if ((count = MpuReadData(regAddr, &b, 1)) != 0) {
        UINT8 mask = ((1 << length) - 1) << (bitStart - length + 1);
        b &= mask;
        b >>= (bitStart - length + 1);
        *data = b;
    }
    return count;
}

/** Read multiple bits from a 16-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to read from
 * @param bitStart First bit position to read (0-15)
 * @param length Number of bits to read (not more than 16)
 * @param data Container for right-aligned value (i.e. '101' read from any bitStart position will equal 0x05)
 * @param timeout Optional read timeout in milliseconds (0 to disable, leave off to use default class value in I2Cdev::readTimeout)
 * @return Status of read operation (1 = success, 0 = failure, -1 = timeout)
 */
UINT8 I2CReadBitsW(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT16 *data) {
    // 1101011001101001 read byte
    // fedcba9876543210 bit numbers
    //    xxx           args: bitStart=12, length=3
    //    010           masked
    //           -> 010 shifted
    UINT8 count;
    UINT16 w;
    if ((count = MpuReadData(regAddr, (UINT8*)&w, 2)) != 0) {
        UINT16 mask = ((1 << length) - 1) << (bitStart - length + 1);
        w &= mask;
        w >>= (bitStart - length + 1);
        *data = w;
    }
    return count;
}


/** write a single bit in an 8-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to write to
 * @param bitNum Bit position to write (0-7)
 * @param value New bit value to write
 * @return Status of operation (true = success)
 */
BOOL I2CWriteBit(UINT8 regAddr, UINT8 bitNum, UINT8 data) {
    UINT8 b;
    MpuReadData(regAddr, &b, 1);
    b = (data != 0) ? (b | (1 << bitNum)) : (b & ~(1 << bitNum));
    return MpuWriteData(regAddr, &b,1);
}

/** write a single bit in a 16-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to write to
 * @param bitNum Bit position to write (0-15)
 * @param value New bit value to write
 * @return Status of operation (true = success)
 */
BOOL I2CWriteBitW(UINT8 regAddr, UINT8 bitNum, UINT16 data) {
    UINT16 w;
    MpuReadData(regAddr, (UINT8*)&w,2);
    w = (data != 0) ? (w | (1 << bitNum)) : (w & ~(1 << bitNum));
    return MpuWriteData(regAddr, (UINT8*)&w,2);
}

/** Write multiple bits in an 8-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to write to
 * @param bitStart First bit position to write (0-7)
 * @param length Number of bits to write (not more than 8)
 * @param data Right-aligned value to write
 * @return Status of operation (true = success)
 */
BOOL I2CWriteBits(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT8 data) {
    //      010 value to write
    // 76543210 bit numbers
    //    xxx   args: bitStart=4, length=3
    // 00011100 mask byte
    // 10101111 original value (sample)
    // 10100011 original & ~mask
    // 10101011 masked | value
    UINT8 b;
    if (MpuReadData(regAddr, &b, 1) != 0) {
        UINT8 mask = ((1 << length) - 1) << (bitStart - length + 1);
        data <<= (bitStart - length + 1); // shift data into correct position
        data &= mask; // zero all non-important bits in data
        b &= ~(mask); // zero all important bits in existing byte
        b |= data; // combine data with existing byte
        return MpuWriteData(regAddr, &b,1);
    } else {
        return FALSE;
    }
}

/** Write multiple bits in a 16-bit device register.
 * @param devAddr I2C slave device address
 * @param regAddr Register regAddr to write to
 * @param bitStart First bit position to write (0-15)
 * @param length Number of bits to write (not more than 16)
 * @param data Right-aligned value to write
 * @return Status of operation (true = success)
 */
BOOL I2CWriteBitsW(UINT8 regAddr, UINT8 bitStart, UINT8 length, UINT16 data) {
    //              010 value to write
    // fedcba9876543210 bit numbers
    //    xxx           args: bitStart=12, length=3
    // 0001110000000000 mask byte
    // 1010111110010110 original value (sample)
    // 1010001110010110 original & ~mask
    // 1010101110010110 masked | value
    UINT16 w;
    if (MpuReadData(regAddr, (UINT8*)&w,2) != 0) {
        UINT8 mask = ((1 << length) - 1) << (bitStart - length + 1);
        data <<= (bitStart - length + 1); // shift data into correct position
        data &= mask; // zero all non-important bits in data
        w &= ~(mask); // zero all important bits in existing word
        w |= data; // combine data with existing word
        return MpuWriteData(regAddr, (UINT8*)&w,2);
    } else {
        return FALSE;
    }
}

